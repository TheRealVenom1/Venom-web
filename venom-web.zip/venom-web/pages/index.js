
import Head from 'next/head'

export default function Home() {
  return (
    <>
      <Head>
        <title>Kiro — TheRealVenom</title>
        <meta name="description" content="Discord Bots & Websites Developer — Kiro (TheRealVenom)" />
      </Head>

      <main className="min-h-screen bg-gradient-to-b from-gray-900 via-purple-900 to-black text-white flex items-center justify-center">
        <section className="w-full max-w-4xl p-6">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="flex-shrink-0">
              <img src="/profile.png" alt="Kiro" className="w-44 h-44 rounded-full object-cover ring-4 ring-purple-700/50"/>
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-pink-400 to-violet-400">
                Kiro <span className="text-base align-super font-medium">TheRealVenom</span>
              </h1>
              <p className="mt-3 text-lg text-gray-300">Discord Bots & Websites Developer</p>
              <div className="mt-6">
                <button className="px-4 py-2 rounded-lg bg-purple-600/80 hover:bg-purple-500 transition">See my work</button>
              </div>
            </div>
          </div>

          <div className="mt-12 text-gray-300 space-y-6">
            <p>
              Welcome — this is a lightweight template built with Next.js + Tailwind CSS.
              It matches the dark gradient style with a circular profile and a subtle scrollable layout.
            </p>
            <p>
              Replace <code>/public/profile.png</code> with your own image to personalize it.
            </p>
            <div className="h-48"></div>
            <p className="text-sm text-gray-400">Made for Kiro — TheRealVenom</p>
          </div>
        </section>
      </main>
    </>
  )
}
