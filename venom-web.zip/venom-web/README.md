# Venom web — Simple Next.js + Tailwind Template

**Personalized for:** Kiro (TheRealVenom)  
**Description:** Discord Bots & Websites Developer

## What's included
- Minimal Next.js project
- Tailwind CSS configured (tailwind.config.js + postcss.config.js)
- `pages/index.js` landing page (dark gradient, circular profile)
- `public/profile.png` placeholder (replace with your photo)

## To run locally
1. Install dependencies:
   ```bash
   npm install
   ```
2. Run development server:
   ```bash
   npm run dev
   ```
3. Open http://localhost:3000

## Deploy to Vercel
1. Push this project to a GitHub repo.
2. Import the repo on https://vercel.com and deploy — Vercel will handle the build.

## Notes
- Replace `public/profile.png` with your real image (keep the same filename).
- This is a *simple* starter template. You can expand sections, add components, and tweak styles.

